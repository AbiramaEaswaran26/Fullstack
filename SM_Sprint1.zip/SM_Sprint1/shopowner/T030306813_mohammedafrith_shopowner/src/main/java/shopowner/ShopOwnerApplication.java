package shopowner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopOwnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopOwnerApplication.class, args);
	}

}
